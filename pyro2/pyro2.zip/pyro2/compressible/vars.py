nvar = 4

# conserved variables -- we set these when we initialize for they match
# the ccData2d object
idens = -1
ixmom = -1
iymom = -1
iener = -1

# for primitive variables 
irho = 0
iu = 1
iv = 2
ip = 3
