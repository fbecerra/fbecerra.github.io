def preevolve(myd):
    
    # do nothing
    pass

